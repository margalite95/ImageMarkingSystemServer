﻿using MessangerContacts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MessangerAPI
{
    public class Messanger:IMessanger
    {
        Dictionary<string, WebSocket> _sockets;
        Dictionary<string, Receiver> _receivers;
        public Messanger()
        {
            _sockets = new Dictionary<string, WebSocket>(); 
        }
        public async Task Send(string id,string message)
        {
            if (_sockets.ContainsKey(id))
            {
                var buffer = Encoding.UTF8.GetBytes(message);
                await _sockets[id].SendAsync(new ReadOnlyMemory<byte>(buffer), WebSocketMessageType.Text
                    ,true
                   ,CancellationToken.None);
            }
        }
        public IReceiver Add(string id, WebSocket socket)
        {
            Receiver retval = null; 
            if (!_sockets.ContainsKey(id))
            {
                _sockets.Add(id, socket);
                
                retval = new Receiver(socket);
            }
            return retval;
            


           
        }

    }
}
