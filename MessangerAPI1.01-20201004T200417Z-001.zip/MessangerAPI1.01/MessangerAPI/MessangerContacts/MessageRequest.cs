﻿using System;

namespace MessangerContacts
{
    public class MessageRequest
    {
        public string ID { get; set; }
        public string Message { get; set; }
    }
}
